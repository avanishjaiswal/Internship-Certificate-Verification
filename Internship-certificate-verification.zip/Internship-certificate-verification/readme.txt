=== Internship Certificate Verification ===
Contributors: Avanish
Donate link: #
Tags: Internship,certificate,verification
Requires at least: 4.0
Tested up to: 4.8
Stable tag: trunk
Requires PHP: 5.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Admin can Store Internship certificate Numbers , and details in the panel and user can verify their certificate using the Certifiacte Number in the front end.

== Description ==

Admin can Store Internship certificate Numbers , and details in the panel and user can verify their certificate using the Certifiacte Number in the front end.

1. To install the Internship Certificate Verification plugin click “Download” or download the plugin from this GitHub repo.
– To install the plugin after downloading it via GitHub, navigate to Plugins → Add New → Upload Plugin and upload the Internship certificate verification.zip file.
2. Once you’ve installed the plugin, activate it through the WordPress plugin panel.
3. Please navigate to the Internship CV menu inside of your WordPress admin panel after activating, and enter the information of the certificate.
5. After you’re done, copy and paste this shortcode: [get_Internship_certificate_search_form] in the page you want to display the search bar of the codes.
6. Once the shortcode has been pasted, you can now go to the page and try searching the certificate information by inserting the code and hit search.
7. You are done ! Everything has been successfully integrate … !

== Installation ==


1. To install the  Internship Certificate Verification plugin click “Download” or download the plugin from this GitHub repo.
– To install the plugin after downloading it via GitHub, navigate to Plugins → Add New → Upload Plugin and upload the Internship certificate verification.zip file.
2. Once you’ve installed the plugin, activate it through the WordPress plugin panel.
3. Please navigate to the Internship CV menu inside of your WordPress admin panel after activating, and enter the information of the certificate.
5. After you’re done, copy and paste this shortcode: [get_Internship_certificate_search_form] in the page you want to display the search bar of the codes.
6. Once the shortcode has been pasted, you can now go to the page and try searching the certificate information by inserting the code and hit search.
7. You are done ! Everything has been successfully integrate … !

== Frequently Asked Questions ==


== Screenshots ==

1. This screen shot shows the menu where users can enter the details of the certificate.
2. This screenshot shows the list of all certificate data entered. 
3. This screenshot shows the front-end design on how it will appear for your visitors to check a certificate No.

== Changelog ==


== Upgrade Notice ==

Contact us at avanish101@gmail.com
